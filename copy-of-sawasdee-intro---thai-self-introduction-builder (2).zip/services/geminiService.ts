
import { GoogleGenAI, Type, Modality } from "@google/genai";
import { UserProfile, ThaiIntroduction, Tone } from "../types";

const API_KEY = process.env.API_KEY || '';

export const generateThaiIntro = async (
  profile: UserProfile,
  tone: Tone
): Promise<ThaiIntroduction> => {
  const ai = new GoogleGenAI({ apiKey: API_KEY });
  
  const prompt = `
    สร้างบทแนะนำตัวภาษาไทยสำหรับบุคคลต่อไปนี้:
    - ชื่อ: ${profile.name}
    - ชื่อเล่น: ${profile.nickname}
    - อาชีพ/การศึกษา: ${profile.occupation}
    - งานอดิเรก: ${profile.hobbies}
    - บ้านเกิด: ${profile.origin}
    - ที่อยู่ปัจจุบัน: ${profile.residence}
    - เป้าหมาย/ความรู้สึก: ${profile.goal}
    - สไตล์ที่ต้องการ: ${tone} (หากเป็นสไตล์ genz ให้ใช้คำศัพท์ที่ทันสมัย มีพลัง และดูเป็นกันเองแบบวัยรุ่นไทย)

    ให้ผลลัพธ์เป็น JSON พร้อมคำอ่าน (phonetic) และคำแปลภาษาอังกฤษ
  `;

  const response = await ai.models.generateContent({
    model: 'gemini-3-flash-preview',
    contents: prompt,
    config: {
      responseMimeType: "application/json",
      responseSchema: {
        type: Type.OBJECT,
        properties: {
          thaiText: { type: Type.STRING, description: 'ข้อความแนะนำตัวภาษาไทย' },
          phonetic: { type: Type.STRING, description: 'คำอ่านแบบโฟเนติก' },
          englishTranslation: { type: Type.STRING, description: 'คำแปลภาษาอังกฤษ' },
          culturalTips: { 
            type: Type.ARRAY, 
            items: { type: Type.STRING },
            description: 'เกร็ดความรู้เล็กๆ น้อยๆ 3 ข้อ' 
          }
        },
        required: ["thaiText", "phonetic", "englishTranslation", "culturalTips"]
      }
    }
  });

  const text = response.text;
  if (!text) throw new Error("Failed to generate content");
  return JSON.parse(text) as ThaiIntroduction;
};

export const playThaiAudio = async (text: string) => {
  const ai = new GoogleGenAI({ apiKey: API_KEY });
  // Using a clear neutral voice
  const voiceName = 'Kore';

  const response = await ai.models.generateContent({
    model: "gemini-2.5-flash-preview-tts",
    contents: [{ parts: [{ text: text }] }],
    config: {
      responseModalities: [Modality.AUDIO],
      speechConfig: {
        voiceConfig: {
          prebuiltVoiceConfig: { voiceName }
        }
      }
    }
  });

  const base64Audio = response.candidates?.[0]?.content?.parts?.[0]?.inlineData?.data;
  if (!base64Audio) return;

  const audioContext = new (window.AudioContext || (window as any).webkitAudioContext)({ sampleRate: 24000 });
  const binaryString = atob(base64Audio);
  const len = binaryString.length;
  const bytes = new Uint8Array(len);
  for (let i = 0; i < len; i++) {
    bytes[i] = binaryString.charCodeAt(i);
  }

  const dataInt16 = new Int16Array(bytes.buffer);
  const buffer = audioContext.createBuffer(1, dataInt16.length, 24000);
  const channelData = buffer.getChannelData(0);
  for (let i = 0; i < dataInt16.length; i++) {
    channelData[i] = dataInt16[i] / 32768.0;
  }

  const source = audioContext.createBufferSource();
  source.buffer = buffer;
  source.connect(audioContext.destination);
  source.start();
};
