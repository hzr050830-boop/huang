
export enum Tone {
  FORMAL = 'formal',
  CASUAL = 'casual',
  GENZ = 'genz'
}

export interface UserProfile {
  name: string;
  nickname: string;
  occupation: string;
  hobbies: string;
  residence: string;
  origin: string;
  goal: string;
}

export interface ThaiIntroduction {
  thaiText: string;
  phonetic: string;
  englishTranslation: string;
  culturalTips: string[];
}

export interface AppState {
  profile: UserProfile;
  introduction: ThaiIntroduction | null;
  isLoading: boolean;
  isAudioLoading: boolean;
  error: string | null;
  selectedTone: Tone;
}
